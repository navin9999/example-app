<div>
    
</div>
<?php /**PATH C:\xampp\htdocs\Navin Yadav\projectapp\resources\views/livewire/about-component.blade.php ENDPATH**/ ?>