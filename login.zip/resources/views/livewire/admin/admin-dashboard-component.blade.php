<div>
<h1>Admin Dashboard</h1>
    {{-- Close your eyes. Count to one. That is how long forever feels. --}}
</div>
